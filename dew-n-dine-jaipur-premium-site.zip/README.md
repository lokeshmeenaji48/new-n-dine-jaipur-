# Dew N Dine — Premium Restaurant Website

This is a static, production-ready restaurant landing site for Dew N Dine, Raja Park, Jaipur.

## Run locally
Open `index.html` directly in a browser, or serve this folder with any static web server.

## Deploy
Upload the folder to Vercel, Netlify, GitHub Pages, or any static host.

## Accuracy notes
- Restaurant details are limited to the verified business information supplied for the build.
- Menu dish names and prices are intentionally not invented.
- Gallery images are royalty-free Unsplash mood references and are clearly labeled as non-business photos.
- Reservation form prepares a WhatsApp request; it does not claim live booking infrastructure.
